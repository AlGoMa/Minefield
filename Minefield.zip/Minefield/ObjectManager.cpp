#include "stdafx.h"

#ifdef __linux
#include <stdio.h>
#endif

#include "ObjectManager.h"
